# Watch8 合约节奏 (ContractPulse) v1.0

独立 **Wear OS** 应用，针对 **Samsung Galaxy Watch8 44mm / 480×480 圆屏** 优化。**仅有手表端 APK，不需要安装手机端 APK**。

## 主屏幕（无需上下滚动）

- 顶部：距离最近提醒的倒计时、当前提醒类型、下一次提醒时刻。
- 第一按钮：**5分钟循环**，每次提醒后自动进入下一轮。
- 第二按钮：**5分钟单次**，到点后自动停止。
- 第三按钮：**15分钟单次**，到点后自动停止。
- 三组**可同时运行**；分别点击可开始/停止，右上 **全停** 可全部停止。
- 底部：**↓ 设置 / 复查**。可以从主页面上滑进入。第二页可滚动。
- 不使用持续亮屏或持续后台循环服务，降低耗电。

## 第二页设置

- **K线收盘对齐**：默认关闭。关闭时从点击时开始计 5m/15m；开启时下一次在钟表分钟 `:00, :05, :10...` 或 `:00, :15, :30, :45` 到点。仅作用于新开始的计时。
- **提前30秒预提醒**：默认关闭，可在运行中切换。
- **振动提醒**：默认开启，分轻、标准、强；可选通知声音（默认静音）。
- **观察清单**：到点通知提示 5m/15m CVD、主动买卖量、成交量，并参考 24h 成交量、OI 和资金费率。
- **通知权限/精确定时权限**：显示状态，允许直接跳到授权界面。
- **全部停止**：随时停止三组计时。

**功能边界**：这个版本是**本地离线定时观察提醒**，不会联网获取任何价格、CVD、交易量或合约指标，不会进行交易。提醒文字是复查清单，绝不代表市场已达到条件。要做“某个币达到目标价后提醒”的实时功能，需要与手机端/交易所行情数据集成，属于后续版本。

## 最简 GitHub 编译（推荐）

1. 打开 <https://github.com/new>，新仓库名填写 `Watch8-ContractPulse`（公开或私有均可），创建空仓库。
2. 进入新仓库 **Add file → Upload files**，上传 **本 ZIP 解压后根目录的全部文件和文件夹**。特别要保留 `.github/workflows/build-apk.yml`。注意：不要将外层 ZIP 当作仓库唯一文件上传。
3. 打开仓库的 **Actions → Build Watch8 ContractPulse APK → Run workflow**。上传完成时若已经自动运行，也可点现有任务。
4. 构建成功后打开 workflow run 底部 **Artifacts → Watch8-ContractPulse-debug**，下载压缩包，里面的 `app-debug.apk` 才是可安装手表 APK。
5. 使用 Wear Installer 2 / 其他 Wear OS APK 安装工具安装在 **手表** 上。打开后先批准通知权限，建议第二页点击「允许精确定时」。

仓库已经内置工作流；GitHub 页面不用手动粘贴 Gradle 构建代码。手动本地编译指令（需要 JDK17、Android SDK 35、Gradle8.11.1）：

```bash
gradle --no-daemon :app:assembleDebug
```

APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 实际提醒的 Android 限制

- Wear OS 和 Android 14+ 通常**默认不允许新安装应用使用精确闹钟**；必须在第二页授权。未授权时采用非精确备用提醒，可能比设定时间晚。获得授权后采用 `setExactAndAllowWhileIdle()`。
- 即便有精确闹钟权限，Doze/省电策略仍可能**限制重复五分钟提醒**；因此不能承诺息屏、深度待机下每次都严格准点。通知权限、系统勿扰模式、佩戴检测和电量也会影响提醒。
- 手表重启后，会恢复原来运行的**循环**提醒；重启过程中已经错过的**单次**提醒不会擅自重新启动。
- 通知会存在手表通知中心；点通知打开主界面。界面中的倒计时在前台每约0.8秒刷新，离开页面后不常驻轮询。
- 自定义振动可能受系统策略限制，勿将其作为唯一风控手段。

## 工程内容

- `app/src/main/java/com/watch8/contractpulse/`：原生 Java / Android 主界面、持久计时器、AlarmManager 接收器、通知。
- `app/src/main/AndroidManifest.xml`：Wear OS 声明与 Android 权限。
- `.github/workflows/build-apk.yml`：GitHub Actions 一键输出调试 APK。
- `tools/test-time-math.sh`：不依赖 Android SDK 的计时逻辑自测。

### 本地自测

```bash
bash tools/test-time-math.sh
```

## 编译状态

源码已在当前工作环境中完成 XML 解析与计时算法测试，但这里未安装 Android SDK/Gradle，**尚未生成或实机验证 APK**。请使用仓库内的 GitHub Actions 进行首次完整编译和 Watch8 真机测试。 

### GitHub Actions SDK 修复（v1.1）
原工作流在 `android-actions/setup-android@v3` 步骤可能因 SDK command-line tools 或许可证处理失败。新版 `.github/workflows/build-apk.yml` 直接使用 GitHub Ubuntu runner 预装的 Android SDK，缺少 API 35 时才用预装 `sdkmanager` 补装，避免原步骤重复下载安装工具。
