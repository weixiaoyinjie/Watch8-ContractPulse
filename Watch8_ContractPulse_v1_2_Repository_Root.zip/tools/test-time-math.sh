#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
out="$(mktemp -d)"
trap 'rm -rf "$out"' EXIT
javac -d "$out" app/src/main/java/com/watch8/contractpulse/TimeMath.java tools/TimeMathTest.java
java -cp "$out" TimeMathTest
