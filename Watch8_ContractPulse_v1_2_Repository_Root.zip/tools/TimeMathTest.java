import com.watch8.contractpulse.TimeMath;
public class TimeMathTest {
    static void check(boolean okay, String name) {
        if (!okay) throw new AssertionError(name);
    }
    public static void main(String[] args) {
        long min = 60_000L;
        check(TimeMath.nextDue(12 * min, 5 * min, false) == 17 * min, "relative five minute");
        check(TimeMath.nextDue(12 * min, 5 * min, true) == 15 * min, "five-minute candle close");
        check(TimeMath.nextDue(15 * min, 5 * min, true) == 20 * min, "strict next close");
        check(TimeMath.nextDue(17 * min, 15 * min, true) == 30 * min, "fifteen-minute close");
        check(TimeMath.nextAfterMissed(5 * min, 16 * min, 5 * min, false) == 20 * min,
                "skip missed loop ticks");
        check(TimeMath.nextAfterMissed(5 * min, 16 * min, 5 * min, true) == 20 * min,
                "skip missed aligned ticks");
        check(TimeMath.nextAfterMissed(25 * min, 16 * min, 5 * min, false) == 25 * min,
                "preserve upcoming alarm");
        System.out.println("PASS: 7 timing tests");
    }
}
