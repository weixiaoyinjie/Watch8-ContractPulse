package com.watch8.contractpulse;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class TimerReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int id = intent.getIntExtra(TimerEngine.EXTRA_ID, -1);
        boolean pre = intent.getBooleanExtra(TimerEngine.EXTRA_PRE, false);
        long due = intent.getLongExtra(TimerEngine.EXTRA_DUE, -1L);
        int generation = intent.getIntExtra(TimerEngine.EXTRA_GEN, -1);
        if (id < 0 || id >= TimerEngine.COUNT) return;
        TimerEngine engine = new TimerEngine(context);
        if (engine.onFire(id, due, generation, pre)) {
            ReminderNotification.show(context, engine, id, pre);
        }
    }
}
