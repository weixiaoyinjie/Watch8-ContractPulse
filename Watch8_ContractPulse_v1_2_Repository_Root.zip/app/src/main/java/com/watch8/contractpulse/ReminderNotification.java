package com.watch8.contractpulse;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;

public final class ReminderNotification {
    private static final String SILENT = "contractpulse_reminder_v1";
    private static final String SOUND = "contractpulse_sound_v1";
    private ReminderNotification() { }

    public static void channels(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel silent = new NotificationChannel(
                SILENT, "合约观察 · 静音", NotificationManager.IMPORTANCE_HIGH);
        silent.setDescription("到点震动，通知不发声；可在手表系统中调整");
        silent.setSound(null, null);
        silent.enableVibration(false); // Vibrator is controlled separately by the user setting.
        silent.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(silent);

        NotificationChannel audible = new NotificationChannel(
                SOUND, "合约观察 · 声音", NotificationManager.IMPORTANCE_HIGH);
        audible.setDescription("合约观察到点声音通知；可在手表系统中调整");
        Uri sound = Settings.System.DEFAULT_NOTIFICATION_URI;
        audible.setSound(sound, new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build());
        audible.enableVibration(false);
        audible.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(audible);
    }

    public static boolean permission(Context context) {
        return Build.VERSION.SDK_INT < 33 ||
                context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        == PackageManager.PERMISSION_GRANTED;
    }

    public static void show(Context context, TimerEngine engine, int id, boolean early) {
        if (engine.vibrate()) buzz(context, engine.vibrationStrength(), early);
        channels(context);
        if (!permission(context)) return;
        NotificationManager nm = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        String title = TimerEngine.title(id) + (early ? " · 剩30秒" : " · 到点");
        String body;
        String expanded;
        if (id == TimerEngine.ONCE_15) {
            body = "15m：CVD / 主动买卖量 / 成交量";
            expanded = "15m CVD、主动买卖量、成交量；对照 5m 趋势和 24h 成交量、OI、资金费率。";
        } else {
            body = "5m：CVD / 主动买卖量 / 成交量";
            expanded = "5m CVD、主动买卖量、成交量；留意价格与交易量背离，并参考 15m / 24h 方向。";
        }
        if (!engine.checklist()) { body = "检查盘口与持仓风险"; expanded = body; }

        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, 80 + id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification note = new Notification.Builder(context, engine.sound() ? SOUND : SILENT)
                .setSmallIcon(R.drawable.ic_watch)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(expanded))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .build();
        // Distinct IDs prevent a running loop from replacing a recent 15m reminder.
        nm.notify(2400 + id * 2 + (early ? 1 : 0), note);
    }

    private static void buzz(Context context, int strength, boolean early) {
        Vibrator v = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        long[] sequence;
        if (early) sequence = new long[] { 0, 110, 75, 110 };
        else if (strength == 0) sequence = new long[] { 0, 120, 100, 120 };
        else if (strength == 2) sequence = new long[] { 0, 250, 100, 250, 120, 310 };
        else sequence = new long[] { 0, 180, 100, 180, 100, 180 };
        try { v.vibrate(VibrationEffect.createWaveform(sequence, -1)); }
        catch (RuntimeException ignored) { /* Respect hardware/device restrictions. */ }
    }
}
