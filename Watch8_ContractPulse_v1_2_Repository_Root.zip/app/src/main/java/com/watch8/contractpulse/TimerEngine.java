package com.watch8.contractpulse;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

/**
 * Three separate persistent alarms. No long-lived background service or polling.
 * All methods touching state are synchronized within the current process.
 */
public final class TimerEngine {
    public static final int LOOP_5 = 0;
    public static final int ONCE_5 = 1;
    public static final int ONCE_15 = 2;
    public static final int COUNT = 3;
    private static final long MIN = 60_000L;
    public static final String EXTRA_ID = "timer_id";
    public static final String EXTRA_DUE = "timer_due";
    public static final String EXTRA_PRE = "timer_pre";
    public static final String EXTRA_GEN = "timer_generation";

    private static final String PREFS = "contractpulse_prefs_v1";
    private static final String PREFIX = "clock_";

    private final Context app;
    private final AlarmManager alarms;
    private final SharedPreferences prefs;

    public TimerEngine(Context context) {
        app = context.getApplicationContext();
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        alarms = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
    }

    public static String title(int id) {
        if (id == LOOP_5) return "5分循环";
        if (id == ONCE_5) return "5分单次";
        return "15分单次";
    }

    public static long length(int id) {
        return id == ONCE_15 ? 15 * MIN : 5 * MIN;
    }

    private static String key(int id, String suffix) { return PREFIX + id + "_" + suffix; }

    public synchronized boolean running(int id) {
        return prefs.getBoolean(key(id, "running"), false);
    }

    public synchronized long due(int id) {
        return prefs.getLong(key(id, "due"), 0);
    }

    public synchronized boolean anyRunning() {
        for (int i = 0; i < COUNT; i++) if (running(i)) return true;
        return false;
    }

    public boolean align() { return prefs.getBoolean("align", false); }
    public boolean early() { return prefs.getBoolean("early", false); }
    public boolean vibrate() { return prefs.getBoolean("vibrate", true); }
    public boolean sound() { return prefs.getBoolean("sound", false); }
    public boolean checklist() { return prefs.getBoolean("checklist", true); }
    public int vibrationStrength() { return prefs.getInt("strength", 1); }

    public synchronized void setOption(String name, boolean enabled) {
        prefs.edit().putBoolean(name, enabled).apply();
        // The 30-second pre-alarm is scheduled or cancelled immediately.
        if ("early".equals(name)) rescheduleAll(false);
    }

    public synchronized void cycleStrength() {
        prefs.edit().putInt("strength", (vibrationStrength() + 1) % 3).apply();
    }

    public boolean exactAllowed() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarms.canScheduleExactAlarms();
    }

    private long nextDue(int id, long now) {
        long duration = length(id);
        // Epoch-aligned minutes: xx:00, :05, :10 (or :00, :15, :30, :45).
        return TimeMath.nextDue(now, duration, align());
    }

    public synchronized void toggle(int id) {
        if (running(id)) stop(id); else start(id);
    }

    public synchronized void start(int id) {
        cancel(id);
        int generation = prefs.getInt(key(id, "gen"), 0) + 1;
        long when = nextDue(id, System.currentTimeMillis());
        prefs.edit().putInt(key(id, "gen"), generation)
                .putBoolean(key(id, "running"), true)
                .putLong(key(id, "due"), when).commit();
        schedule(id);
    }

    public synchronized void stop(int id) {
        cancel(id);
        int generation = prefs.getInt(key(id, "gen"), 0) + 1;
        prefs.edit().putInt(key(id, "gen"), generation)
                .putBoolean(key(id, "running"), false)
                .putLong(key(id, "due"), 0L).commit();
    }

    public synchronized void stopAll() {
        for (int id = 0; id < COUNT; id++) stop(id);
    }

    private PendingIntent intentFor(int id, boolean pre, int generation, long when) {
        Intent intent = new Intent(app, TimerReceiver.class);
        intent.setAction("com.watch8.contractpulse.ALARM_" + id + (pre ? "_PRE" : "_DUE"));
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_DUE, when);
        intent.putExtra(EXTRA_PRE, pre);
        intent.putExtra(EXTRA_GEN, generation);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(app, 3010 + id * 2 + (pre ? 1 : 0), intent, flags);
    }

    private void cancel(int id) {
        for (boolean pre : new boolean[] { false, true }) {
            // Same request codes + action; extras do not affect PendingIntent identity.
            PendingIntent p = intentFor(id, pre, 0, 0);
            alarms.cancel(p);
            p.cancel();
        }
    }

    private void scheduleOne(long at, PendingIntent p) {
        if (exactAllowed()) {
            try {
                alarms.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
                return;
            } catch (SecurityException ignored) { /* Permission was revoked. */ }
        }
        // Doze can delay this fallback, so the settings screen surfaces this condition.
        alarms.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, p);
    }

    private void schedule(int id) {
        if (!running(id)) return;
        long when = due(id);
        long now = System.currentTimeMillis();
        int gen = prefs.getInt(key(id, "gen"), 0);
        if (early() && when - 30_000L > now + 1000L) {
            scheduleOne(when - 30_000L, intentFor(id, true, gen, when));
        }
        scheduleOne(Math.max(now + 1000L, when), intentFor(id, false, gen, when));
    }

    /** Reconstruct after process death/reboot/permission change. */
    public synchronized void rescheduleAll(boolean afterRebootOrClockChange) {
        long now = System.currentTimeMillis();
        for (int id = 0; id < COUNT; id++) {
            cancel(id);
            if (!running(id)) continue;
            long when = due(id);
            if (afterRebootOrClockChange && when <= now) {
                if (id == LOOP_5) {
                    long next = TimeMath.nextAfterMissed(when, now, length(id), align());
                    prefs.edit().putLong(key(id, "due"), next).commit();
                } else {
                    // A missed one-shot after reboot is not silently restarted as a fresh timer.
                    prefs.edit().putBoolean(key(id, "running"), false)
                            .putLong(key(id, "due"), 0L).commit();
                    continue;
                }
            }
            schedule(id);
        }
    }

    /** Returns true only for a valid, current generation alarm. */
    public synchronized boolean onFire(int id, long when, int gen, boolean pre) {
        if (id < 0 || id >= COUNT || !running(id)) return false;
        if (prefs.getInt(key(id, "gen"), 0) != gen || due(id) != when) return false;
        long now = System.currentTimeMillis();
        if (pre) return early() && now < when && now >= when - 90_000L;
        if (now + 2000 < when) { schedule(id); return false; }

        // Commit new state and schedule the next cycle BEFORE doing notification work.
        if (id == LOOP_5) {
            long next = TimeMath.nextAfterMissed(when, now, length(id), align());
            prefs.edit().putLong(key(id, "due"), next).commit();
            cancel(id);
            schedule(id);
        } else {
            prefs.edit().putBoolean(key(id, "running"), false)
                    .putLong(key(id, "due"), 0L).commit();
            cancel(id);
        }
        return true;
    }
}
