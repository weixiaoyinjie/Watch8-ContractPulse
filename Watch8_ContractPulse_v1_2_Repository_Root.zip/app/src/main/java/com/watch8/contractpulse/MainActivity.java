package com.watch8.contractpulse;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Watch8 44mm: main screen is a single non-scrolling Canvas; settings live below it. */
public final class MainActivity extends Activity {
    private TimerEngine engine;
    private Dashboard dashboard;
    private ScrollView settingsScroll;
    private int settingsY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean settingsVisible;
    private float startX, startY;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!settingsVisible && dashboard != null) {
                dashboard.invalidate();
                handler.postDelayed(this, 800L);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        engine = new TimerEngine(this);
        ReminderNotification.channels(this);
        showDashboard();
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 100);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        // Re-register alarms in case the user just granted exact-alarm access.
        engine.rescheduleAll(false);
        handler.removeCallbacks(ticker);
        if (settingsVisible) showSettings();
        else if (dashboard != null) handler.post(ticker);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private int dp(float value) {
        return (int) (getResources().getDisplayMetrics().density * value + 0.5f);
    }

    private void showDashboard() {
        settingsVisible = false;
        settingsY = 0;
        dashboard = new Dashboard();
        setContentView(dashboard);
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    private TextView text(String content, float sizeSp, int color) {
        TextView t = new TextView(this);
        t.setText(content);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(3), dp(5), dp(3), dp(5));
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(Color.rgb(223, 245, 228));
        b.setAllCaps(false);
        b.setMinimumHeight(dp(36));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void checkboxOption(LinearLayout page, String pref, String label,
                                String description) {
        Button b = button((readOption(pref) ? "✓  " : "○  ") + label, () -> {
            engine.setOption(pref, !readOption(pref));
            showSettings();
        });
        page.addView(b);
        page.addView(text(description, 10, Color.rgb(144, 159, 153)));
    }

    private boolean readOption(String pref) {
        switch (pref) {
            case "align": return engine.align();
            case "early": return engine.early();
            case "vibrate": return engine.vibrate();
            case "sound": return engine.sound();
            case "checklist": return engine.checklist();
            default: return false;
        }
    }

    private void showSettings() {
        if (settingsVisible && settingsScroll != null) settingsY = settingsScroll.getScrollY();
        handler.removeCallbacks(ticker);
        settingsVisible = true;
        settingsScroll = new ScrollView(this);
        settingsScroll.setBackgroundColor(Color.rgb(7, 10, 16));
        settingsScroll.setFillViewport(true);
        settingsScroll.setVerticalScrollBarEnabled(false);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        int width = getResources().getDisplayMetrics().widthPixels;
        int pad = Math.round(width * 0.145f);
        page.setPadding(pad, dp(18), pad, dp(25));

        page.addView(text("合约节奏 · 设置", 15, Color.rgb(145, 255, 162)));
        page.addView(button("↑ 返回计时主页", this::showDashboard));
        page.addView(text("滑动查看 · 下方设置不占主页空间", 10, Color.LTGRAY));

        checkboxOption(page, "align", "K线收盘对齐", "开启后新启动的5/15分钟计时，到下一个 00/05/10 或 00/15/30/45 分钟点提醒；关闭则从点击时计时。");
        checkboxOption(page, "early", "提前30秒预提醒", "单次和循环均可预提醒；切换后作用于运行中的计时器。");
        checkboxOption(page, "vibrate", "手表震动提醒", "默认开启。系统勿扰模式、佩戴检测可能影响实际提醒。");
        String[] strengths = {"轻", "标准", "强"};
        page.addView(button("震动强度：" + strengths[engine.vibrationStrength()], () -> {
            engine.cycleStrength();
            showSettings();
        }));
        checkboxOption(page, "sound", "通知提示音", "默认关闭；开启后选择独立的有声通知渠道，系统通知设置仍有优先权。");
        checkboxOption(page, "checklist", "通知显示复查要点", "到点时显示精简的 CVD、主动买卖量与成交量复查文字。");

        int good = Color.rgb(149, 255, 164);
        int warn = Color.rgb(255, 192, 112);
        page.addView(text("系统提醒权限", 14, good));
        page.addView(text("通知：" + (ReminderNotification.permission(this) ? "已允许" : "未允许")
                + "    精确定时：" + (engine.exactAllowed() ? "已允许" : "未允许"), 11,
                engine.exactAllowed() && ReminderNotification.permission(this) ? good : warn));
        if (!ReminderNotification.permission(this)) {
            page.addView(button("开启通知权限", () -> {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, 101);
                }
            }));
        }
        if (!engine.exactAllowed()) {
            page.addView(button("允许精确定时（建议）", this::requestExactAlarm));
        }
        page.addView(text("未授权精确定时时，使用系统非精确备用闹钟，息屏后可能延迟。即使授权，系统省电/勿扰仍可能影响五分钟到点体验。", 10,
                Color.rgb(252, 194, 115)));

        page.addView(text("到点后观察清单", 14, good));
        page.addView(text("5分钟：CVD 方向 / 主动买入卖出量 / 5m 成交量 / 价格背离", 11,
                Color.rgb(212, 226, 217)));
        page.addView(text("15分钟：15m CVD / 主动买卖强度 / 15m 成交量 / 趋势确认", 11,
                Color.rgb(212, 226, 217)));
        page.addView(text("24小时背景：24h 成交量 / OI / 资金费率 / 多空环境", 11,
                Color.rgb(212, 226, 217)));
        page.addView(text("注意：本应用是离线提醒器，不会读取币安实时价格、CVD、成交量或自动产生交易信号；需在您的行情应用内核对。", 10,
                Color.rgb(161, 172, 166)));
        page.addView(button("停止全部计时", () -> {
            new AlertDialog.Builder(this).setTitle("停止全部提醒？")
                    .setPositiveButton("停止", (d, w) -> { engine.stopAll(); showDashboard(); })
                    .setNegativeButton("取消", null).show();
        }));
        settingsScroll.addView(page, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(settingsScroll);
        settingsScroll.post(() -> settingsScroll.scrollTo(0, settingsY));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                                     int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (settingsVisible) showSettings();
    }

    private void requestExactAlarm() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (RuntimeException ex) {
            Toast.makeText(this, "请到系统设置中允许闹钟与提醒", Toast.LENGTH_LONG).show();
        }
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
            startX = ev.getX(); startY = ev.getY();
        } else if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
            float dx = ev.getX() - startX;
            float dy = ev.getY() - startY;
            float h = getResources().getDisplayMetrics().heightPixels;
            float w = getResources().getDisplayMetrics().widthPixels;
            if (Math.abs(dx) < w * 0.23f && Math.abs(dy) > h * 0.20f) {
                if (!settingsVisible && dy < 0) {
                    showSettings(); return true;
                }
                if (settingsVisible && dy > 0 && settingsScroll != null
                        && settingsScroll.getScrollY() == 0 && startY < h * 0.38f) {
                    showDashboard(); return true;
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override public void onBackPressed() {
        if (settingsVisible) showDashboard(); else super.onBackPressed();
    }

    private final class Dashboard extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm", Locale.CHINA);
        private final int green = Color.rgb(137, 245, 160);
        private final int white = Color.rgb(238, 249, 242);
        private final int gray = Color.rgb(157, 178, 169);
        private float touchX, touchY;

        Dashboard() { super(MainActivity.this); }

        private void centered(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setStyle(Paint.Style.FILL); p.setColor(color);
            p.setTypeface(bold ? android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
                    : android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL));
            p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER);
            c.drawText(s, x, y - (p.ascent() + p.descent()) * .5f, p);
        }

        private void rounded(Canvas c, float left, float top, float right, float bottom,
                             float radius, int fill, int edge, float stroke) {
            RectF r = new RectF(left, top, right, bottom);
            p.setStyle(Paint.Style.FILL); p.setColor(fill);
            c.drawRoundRect(r, radius, radius, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(stroke); p.setColor(edge);
            c.drawRoundRect(r, radius, radius, p);
            p.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            final float w = getWidth(), h = getHeight();
            c.drawColor(Color.rgb(7, 10, 16));
            float mid = w * .5f;
            centered(c, "合约节奏  ·  WATCH8", mid, h * .12f, h * .043f, green, true);
            centered(c, "全停", w * .77f, h * .183f, h * .034f,
                    engine.anyRunning() ? Color.rgb(255, 167, 160) : gray, true);

            long now = System.currentTimeMillis();
            int nearest = -1; long nearestAt = Long.MAX_VALUE;
            for (int id = 0; id < TimerEngine.COUNT; id++) {
                if (engine.running(id) && engine.due(id) < nearestAt) {
                    nearestAt = engine.due(id); nearest = id;
                }
            }
            if (nearest < 0) {
                centered(c, "--:--", mid, h * .286f, h * .135f, white, true);
                centered(c, "点击下方按钮开始观察", mid, h * .374f, h * .035f, gray, false);
            } else {
                centered(c, remaining(nearestAt, now), mid, h * .286f, h * .139f, green, true);
                centered(c, TimerEngine.title(nearest) + "  ·  " + dateFormat.format(new Date(nearestAt)),
                        mid, h * .374f, h * .036f, white, false);
            }

            for (int id = 0; id < TimerEngine.COUNT; id++) {
                float centerY = h * (.469f + id * .134f);
                boolean running = engine.running(id);
                int fill = running ? Color.rgb(24, 60, 43) : Color.rgb(26, 32, 40);
                int outline = running ? Color.rgb(118, 225, 147) : Color.rgb(62, 77, 77);
                rounded(c, w * .165f, centerY - h * .056f,
                        w * .835f, centerY + h * .056f, h * .043f,
                        fill, outline, Math.max(1.1f, w * .0025f));
                centered(c, TimerEngine.title(id), w * .352f, centerY, h * .047f, white, true);
                String status = running ? remaining(engine.due(id), now) : "▶ 开始";
                centered(c, status, w * .680f, centerY, h * .041f,
                        running ? green : gray, true);
            }

            rounded(c, w * .275f, h * .842f, w * .725f, h * .910f, h * .034f,
                    Color.rgb(27, 37, 40), Color.rgb(74, 91, 83), 1.3f);
            centered(c, "↓ 设置 / 复查", mid, h * .876f, h * .036f, white, false);
            centered(c, "点按：启动 / 停止  ·  上滑：设置", mid, h * .960f,
                    h * .026f, gray, false);
        }

        private String remaining(long due, long now) {
            long remaining = Math.max(0, (due - now + 999) / 1000);
            long m = remaining / 60;
            long s = remaining % 60;
            return String.format(Locale.US, "%02d:%02d", m, s);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touchX = event.getX(); touchY = event.getY(); return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                float w = getWidth(), h = getHeight();
                float x = event.getX(), y = event.getY();
                if (Math.abs(x - touchX) > w * .10f || Math.abs(y - touchY) > h * .10f) return true;
                if (y > h * .144f && y < h * .224f && x > w * .67f && x < w * .90f) {
                    if (engine.anyRunning()) {
                        new AlertDialog.Builder(MainActivity.this).setTitle("停止全部计时？")
                                .setPositiveButton("全部停止", (d, ww) -> { engine.stopAll(); invalidate(); })
                                .setNegativeButton("取消", null).show();
                    }
                    return true;
                }
                for (int id = 0; id < TimerEngine.COUNT; id++) {
                    float centerY = h * (.469f + id * .134f);
                    if (x >= w * .165f && x <= w * .835f &&
                            y >= centerY - h * .057f && y <= centerY + h * .057f) {
                        engine.toggle(id);
                        invalidate();
                        return true;
                    }
                }
                if (x > w * .25f && x < w * .75f && y > h * .82f && y < h * .93f) {
                    showSettings(); return true;
                }
                return true;
            }
            return true;
        }
    }
}
