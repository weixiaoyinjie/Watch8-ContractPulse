package com.watch8.contractpulse;

/** Pure Java timing calculations, testable without the Android SDK. */
public final class TimeMath {
    private TimeMath() {}

    public static long nextDue(long now, long duration, boolean aligned) {
        if (duration <= 0) throw new IllegalArgumentException("duration must be positive");
        if (!aligned) return now + duration;
        return (Math.floorDiv(now, duration) + 1) * duration;
    }

    public static long nextAfterMissed(long oldDue, long now, long duration, boolean aligned) {
        if (aligned) return nextDue(now, duration, true);
        if (oldDue > now) return oldDue;
        return oldDue + ((now - oldDue) / duration + 1) * duration;
    }
}
